<?php
include("./dbConnection.php");

if (isset($_POST['hallticket'])) {
    $rollno = $_POST['rollno'];
    $stuname = $_POST['stuname'];
    $clgname = $_POST['clgname'];
    // $subject = $_POST['subject'];


    $res = $con->query("SELECT * FROM quiz");
    $date = $_POST['edate'];
    foreach ($date as $dot) {
        $sql = "INSERT INTO hallticket(rollno,stuname,clgname,dateandtime) VALUES('$rollno','$stuname','$clgname','$dot')";
        $con->query($sql);
    }
    header("Location: dash.php?q=5");
    // echo "inserted successfull";
    exit();
}
